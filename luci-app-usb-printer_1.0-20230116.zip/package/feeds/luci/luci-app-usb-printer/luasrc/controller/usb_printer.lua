--[[
LuCI - Lua Configuration Interface

Copyright 2008 Steven Barth <steven@midlink.org>

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

	http://www.apache.org/licenses/LICENSE-2.0

$Id$
]]--

require("luci.sys")

module("luci.controller.usb_printer", package.seeall)

function index()
        if not nixio.fs.access("/etc/config/usb_printer") then
		return
	end
	
	
	local page
	
	page = entry({"admin", "services", "usb_printer"}, cbi("usb_printer"), _("Multi-Printer Server"), 60)
end
